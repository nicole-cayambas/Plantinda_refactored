
<?php $__env->startSection('content'); ?>
<div class="w-full">
<p class="w-full text-center text-emerald-600">
    <?php echo e(session('status')); ?>

</p>
<div class="w-full p-4 flex justify-center">
    
    <form action="<?php echo e(route('sendMessage')); ?>" method="POST" class="w-full sm:w-4/5 border-2 p-4 flex flex-col gap-4 rounded-lg">
        <?php echo csrf_field(); ?>
        <p class="font-bold">Compose Message</p>
        <div>
            <label for="seller_email">Send To</label>
            <input type="text" name="seller_email" id="seller_email" value="<?php echo e($seller->email); ?>" class="p-2 focus:outline-none focus:bg-gray-100 border-2 w-full" readonly>
            <input type="text" name="store_name" id="store_name" value="<?php echo e($store->name); ?>" class="p-2 focus:outline-none focus:bg-gray-100 border-2 w-full" readonly>
            <input type="number" name="to" value="<?php echo e($seller->id); ?>" hidden>
            <input type="number" name="from" value="<?php echo e(auth()->user()->id); ?>" hidden>
        </div>
        <div>
            <input class="p-2 focus:outline-none focus:bg-gray-100 border-2 w-full" type="text" name="subject" placeholder="Subject">
        </div>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div>
            <textarea class="p-2 focus:outline-none focus:bg-gray-100 border-2 w-full h-36" name="body" placeholder="Body"></textarea>
        </div>
        <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div>
            <label for="product_name" class="font-semibold">Product:</label>
            <input type="text" name="product_name" id="product_name" value="<?php echo e($product->name); ?>" class="p-2 focus:outline-none focus:bg-gray-100 border-2 w-full" readonly>
            <input type="number" name="product_id" value="<?php echo e($product->id); ?>" hidden>
        </div>
        <div class="flex justify-center mt-10">
            <button type="submit" class="w-1/2 bg-emerald-400 rounded-lg p-4 hover:bg-emerald-500">Send</button>
        </div>
    </form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plantinda_\resources\views/message/create.blade.php ENDPATH**/ ?>