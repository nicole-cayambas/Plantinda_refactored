
<a href="<?php echo e(route('showStore', ['id'=>$store->id])); ?>" id="store-card" class="mt-4 rounded-xl border-2 p-4 w-full flex flex-col sm:grid sm:grid-cols-4 gap-4">
    <div class="flex flex-col col-span-2 gap-2">
        <div class="flex flex-row gap-2 items-center">
            <img src="<?php if($store->image): ?><?php echo e(asset('images/store_images/'.$store->image)); ?> <?php else: ?> <?php echo e(asset('images/store_images/null.png')); ?> <?php endif; ?>" class="rounded-circle w-6 h-6">
            <strong class="text-lg"><?php echo e($store->name); ?></strong>
        </div>
        <p><?php echo e($store->certifications); ?></p>
        <div class="w-full sm:w-1/2 h-36">
            <img src="<?php if($store->banner_image): ?><?php echo e(asset('images/store_banners/'.$store->banner_image)); ?> <?php else: ?> <?php echo e(asset('images/store_banners/null.png')); ?> <?php endif; ?>" class="w-full h-full rounded-lg"> 
        </div>
        <p>Seller: <strong><?php echo e($store->user->username); ?></strong></p>
    </div>
    <div class="flex flex-col gap-2 justify-center">
        <p>Main products: <strong><?php echo e($store->main_products); ?></strong></p>
        <p>Main markets: <strong><?php echo e($store->main_markets); ?></strong></p>
    </div>
    <div class="flex flex-col gap-2 justify-center">
        <p>Response time: <strong><?php echo e($store->response_time); ?>%</strong></p>
        <p>Delivery rate: <strong><?php echo e($store->delivery_rate); ?>%</strong></p>
        <p>Number of transactions: <strong><?php echo e($store->num_transactions); ?></strong></p>
    </div>
    
</a><?php /**PATH C:\xampp\htdocs\plantinda_\resources\views/components/store.blade.php ENDPATH**/ ?>