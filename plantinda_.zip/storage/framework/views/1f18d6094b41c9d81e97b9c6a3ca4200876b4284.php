
<?php $__env->startSection('admin_content'); ?>
<?php if(auth()->guard()->check()): ?>
<div class="flex flex-col w-full">
    <div class="px-4 m-0 sm:m-4">
        <h1>Good Day <?php if(auth()->guard()->check()): ?> <?php echo e(Auth()->user()->first_name); ?> <?php endif; ?>!</h1>
    </div>
    <div class="w-full p-4 grid grid-cols-2 lg:grid-cols-3 gap-4">
        <div class="bg-emerald-200 rounded-lg p-2">
            <h2 class="text-lg text-center">Total Users</h2>
            <h1 class="text-2xl text-center"><?php echo e($total_users); ?></h1>
        </div>
        <div class="bg-emerald-200 rounded-lg p-2">
            <h2 class="text-lg text-center">Total Sellers</h2>
            <h1 class="text-2xl text-center"><?php echo e($total_sellers); ?></h1>
        </div>
        <div class="bg-emerald-200 rounded-lg p-2">
            <h2 class="text-lg text-center">Total Buyers</h2>
            <h1 class="text-2xl text-center"><?php echo e($total_buyers); ?></h1>
        </div>
        <div class="bg-emerald-200 rounded-lg p-2">
            <h2 class="text-lg text-center">Total Stores</h2>
            <h1 class="text-2xl text-center"><?php echo e($total_stores); ?></h1>
        </div>
        <div class="bg-emerald-200 rounded-lg p-2">
            <h2 class="text-lg text-center">Today's Orders Created</h2>
            <h1 class="text-2xl text-center"><?php echo e($today_orders); ?></h1>
        </div>
        <div class="bg-emerald-200 rounded-lg p-2">
            <h2 class="text-lg text-center">Today's Completed Orders</h2>
            <h1 class="text-2xl text-center"><?php echo e($today_completed_orders); ?></h1>
        </div>

    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plantinda_\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>