
<?php $__env->startSection('content'); ?>

<p class="w-full text-center m-4 text-emerald-600">
    <?php echo e(session('success')); ?>

</p>
<div class="w-full flex justify-center p-4">
    <form action="<?php echo e(route('editReview', ['id' => $product->id])); ?>" method="POST" class="w-full sm:w-1/2">
        <?php echo csrf_field(); ?>
        <strong> <?php echo e($product->name); ?> </strong>

        <div>
            <label for="rating">Rating</label>
            <input type="text" value="<?php echo e($review->rating); ?>" name="rating" id="rating" class="mt-1 p-2 focus:ring-indigo-500 border-2 focus:border-indigo-500 block w-1/8 shadow-sm sm:text-sm border-gray-300 rounded-md">
        </div>
        <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div>
            <label for="comment">Comment</label>
            <textarea name="comment" id="comment" class="mt-1 p-2 focus:ring-indigo-500 border-2 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"><?php echo e($review->comment); ?></textarea>
        </div>
        <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <button type="submit" class="mt-2 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500">Submit</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plantinda_\resources\views/reviews/edit.blade.php ENDPATH**/ ?>