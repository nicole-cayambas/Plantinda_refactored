
<?php $__env->startSection('content'); ?>
<div class="w-full">
    <p class="w-full text-center text-emerald-600">
        <?php echo e(session('success')); ?>

    </p>
    <h1 class="px-4">Messages</h1>
    <div class="mt-5">
        <ul class="flex flex-col gap-2 px-4">
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="rounded p-2 <?php if($message->from === auth()->user()->id): ?> bg-green-200 <?php else: ?> bg-gray-200 <?php endif; ?>">
                <a href="<?php echo e(route('showMessageBuyer',['id'=>$message->id])); ?>" class="flex flex-row justify-between items-center">
                    <div>
                        <h1><?php echo e($message->subject); ?></h1>
                        <p>From: <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></p>
                    </div>
                    <p><?php echo e($message->created_at); ?></p>
                </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plantinda_\resources\views/message/index.blade.php ENDPATH**/ ?>