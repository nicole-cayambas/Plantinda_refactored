
<?php $__env->startSection('dash_content'); ?>
<div class="w-full">
<p class="w-full text-center text-emerald-600">
    <?php echo e(session('status')); ?>

</p>
<div class="w-full p-4 flex justify-center">
    
    <form action="<?php echo e(route('saveStore')); ?>" enctype="multipart/form-data" method="POST" class="w-full sm:w-4/5 border-2 p-4 flex flex-col gap-4 rounded-lg">
        <?php echo csrf_field(); ?>
        <p class="font-bold">Store Information</p>
        <div>
            <input class="p-2 focus:outline-none focus:bg-gray-100 border-2 w-full" type="text" name="name" placeholder="Store Name" <?php if($store): ?> value="<?php echo e($store->name); ?>" <?php endif; ?>>
        </div>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div>
            <textarea class="p-2 focus:outline-none focus:bg-gray-100 border-2 w-full h-36" name="description" placeholder="Description"><?php if($store): ?><?php echo $store->description; ?><?php endif; ?></textarea>
        </div>
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div>
            <input class="p-2 focus:outline-none focus:bg-gray-100 border-2 w-full" type="text" name="main_products" placeholder="Main Products (e.g. Vegetables, Flowers, Seeds)" <?php if($store): ?> value="<?php echo e($store->main_products); ?>" <?php endif; ?>>
        </div>
        <?php $__errorArgs = ['main_products'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div>
            <input class="p-2 focus:outline-none focus:bg-gray-100 border-2 w-full" type="text" name="main_markets" placeholder="Main Markets (e.g. Restaurants, Souvenir Shops, Home Gardens)" <?php if($store): ?> value="<?php echo e($store->main_markets); ?>" <?php endif; ?>>
        </div>
        <?php $__errorArgs = ['main_markets'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="flex flex-col sm:flex-row w-full sm:justify-evenly">
            <div>
                <label class="block text-sm font-medium text-gray-700"> Store Photo </label>
                    <div class="mt-1 flex items-center gap-4">
                        <span class="inline-block h-12 w-12 rounded-full overflow-hidden bg-gray-200">
                        <?php if($store): ?>
                            <?php if($store->image): ?>
                                <img class="rounded-circle w-full h-full" src="<?php echo e(asset('images/store_images/'.$store->image)); ?>" alt="">
                            <?php else: ?>
                                <img class="rounded-circle w-full h-full" src="<?php echo e(asset('images/store_images/null.png')); ?>" alt="">
                            <?php endif; ?>
                        <?php endif; ?>
                        </span>
                        <input id="choose-file" type="file" name="image" accept=".jpg, .jpeg, .png, .gif, .svg" hidden>
                        <button onClick="showChooser()" type="button" class="w-20 border-2 rounded-lg hover:bg-gray-200 p-2">Change</button>
                        <p id="fileName"></p>
                    </div>

            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700"> Store Banner </label>
                <div class="mt-1 flex items-center gap-4">
                    <span class="inline-block h-12 w-40 overflow-hidden bg-gray-200">
                        <?php if($store): ?>
                            <?php if($store->banner_image): ?>
                                <img class="rounded-lg w-full h-full" src="<?php echo e(asset('images/store_banners/'.$store->banner_image)); ?>" alt="">
                            <?php else: ?>
                                <img class="rounded-lg w-full h-full" src="<?php echo e(asset('images/store_banners/null.png')); ?>" alt="">
                            <?php endif; ?>
                        <?php endif; ?>
                    </span>
                    <input id="choose-banner" type="file" name="banner_image" accept=".jpg, .jpeg, .png, .gif, .svg" hidden>
                    <button id="banner_btn" type="button" class="w-20 border-2 rounded-lg hover:bg-gray-200 p-2">Change</button>
                    <p id="bannerName"></p>
                </div>
            </div>
        </div>
        <div class="flex justify-center mt-10">
            <button type="submit" class="w-1/2 bg-emerald-400 rounded-lg p-4 hover:bg-emerald-500">Save</button>
        </div>
    </form>
</div>
</div>

<script>
    const fileSelector = document.getElementById('choose-file');
    const bannerSelector = document.getElementById('choose-banner');
    function showChooser() {
      fileSelector.click();
    }
    fileSelector.addEventListener('change', (event) => {
      const fileList = event.target.files;
      const file = fileList[0];
      const fileName = document.getElementById('fileName');
      fileName.innerHTML = file.name;
    });

    bannerSelector.addEventListener('change', (event) => {
      const fileList = event.target.files;
      const file = fileList[0];
      const fileName = document.getElementById('bannerName');
      fileName.innerHTML = file.name;
    });

    const bannerBtn = document.getElementById('banner_btn');
    bannerBtn.addEventListener('click', (event) => {
      bannerSelector.click();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plantinda_\resources\views/dashboard/store/edit.blade.php ENDPATH**/ ?>