
<?php $__env->startSection('content'); ?>
<p class="w-full text-center text-emerald-600">
    <?php echo e(session('success')); ?>

</p>
<div class="flex flex-col p-2 md:px-12 lg:px-32">
    <div class="overflow-x-auto sm:-mx-6 lg:-mx-8">
        <div class="inline-block py-2 min-w-full sm:px-6 lg:px-8">
            <div class="overflow-hidden shadow-md w-full sm:rounded-lg">
                <?php if(count($cart_items) > 0): ?>
                <table class="min-w-full">
                    <thead class="bg-gray-100 dark:bg-gray-700">
                        <tr>
                            <th scope="col" class="py-3 px-6 text-xs font-medium tracking-wider text-left text-gray-700 uppercase dark:text-gray-400">
                                Name
                            </th>
                            <th scope="col" class="py-3 px-6 text-xs font-medium tracking-wider text-left text-gray-700 uppercase dark:text-gray-400">
                                Quantity x Price
                            </th>
                            <th scope="col" class="py-3 px-6 text-xs font-medium tracking-wider text-left text-gray-700 uppercase dark:text-gray-400">
                                Shipping
                            </th>
                            <th scope="col" class="py-3 px-6 text-xs font-medium tracking-wider text-left text-gray-700 uppercase dark:text-gray-400">
                                Total Price
                            </th>
                            <th scope="col" class="relative py-3 px-6">
                                <span class="sr-only">Edit</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cart_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-b odd:bg-white even:bg-gray-50 odd:dark:bg-gray-800 even:dark:bg-gray-700 dark:border-gray-600">
                                <form action="<?php echo e(route('sendOrder', ['id', $cart_item->id])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="number" name="product_id" value="<?php echo e($cart_item->product->id); ?>" hidden>
                                    <input type="text" name="product_name" value="<?php echo e($cart_item->product->name); ?>" hidden>
                                    <input type="number" name="quantity" value="<?php echo e($cart_item->quantity); ?>" hidden>
                                    <input type="number" name="price" value="<?php echo e($cart_item->unit_price); ?>" hidden>
                                    <input type="number" name="shipping" value="<?php echo e($cart_item->shipping_price); ?>" hidden>
                                    <input type="number" name="total" value="<?php echo e($cart_item->total_price); ?>" hidden>
                                    <input type="number" name="cart_id" value="<?php echo e($cart_item->id); ?>" hidden>
                                    <input type="radio" name="from_cart" checked hidden>
                                    <td class="py-4 px-6 text-sm font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                        <?php echo e($cart_item->product->name); ?> <br> <br> <img src="<?php echo e($cart_item->product->image); ?>" alt="<?php echo e($cart_item->product->name); ?> picture" width="100px" height="100px">
                                    </td>
                                    <td class="py-4 px-6 text-sm text-gray-500 whitespace-nowrap dark:text-gray-400">
                                        <?php echo e($cart_item->quantity); ?> x Php <?php echo e(number_format($cart_item->unit_price, 2)); ?>

                                    </td>
                                    <td class="py-4 px-6 text-sm text-gray-500 whitespace-nowrap dark:text-gray-400">
                                        Php <?php echo e(number_format($cart_item->shipping_price, 2)); ?>

                                    </td>
                                    <td class="py-4 px-6 text-sm text-gray-500 whitespace-nowrap dark:text-gray-400">
                                        Php <?php echo e(number_format($cart_item->total_price, 2)); ?>

                                    </td>
                                    <td class="py-4 px-6 text-sm font-medium text-center whitespace-nowrap">
                                        <button name="submit" value="sendOrder" class="p-4 hover:bg-slate-400 text-center bg-slate-200 rounded-lg " type="submit">Checkout</button>
                                        <br>
                                        
                                        <a href="<?php echo e(route('deleteCart', ['id' => $cart_item->id])); ?>" class="text-red-600 dark:text-red-500 hover:underline">Delete</a>
                                    </td>
                                </form>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php else: ?>
                    <p>No items in cart</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plantinda_\resources\views/cart/index.blade.php ENDPATH**/ ?>