<ul role="list" class="font-medium text-gray-900 px-2 py-3">
    <li>
        <a href="<?php echo e(route('stores')); ?>" class="block px-2 py-3">Stores</a>
    </li>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <a href="#" class="block px-2 py-3"> <?php echo e($category->name); ?> </a>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\xampp\htdocs\plantinda_\resources\views/components/categories.blade.php ENDPATH**/ ?>