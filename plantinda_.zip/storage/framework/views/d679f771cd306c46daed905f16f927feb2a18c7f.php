<div class="group relative rounded-lg shadow-lg p-4 sm:p-2">
    <div class="w-full min-h-80 bg-gray-200 aspect-w-1 rounded-lg aspect-h-1 rounded-md overflow-hidden group-hover:opacity-75 lg:h-80 lg:aspect-none">
        <?php if(!str_starts_with($product->image, 'http')): ?>
            <img src="<?php echo e(asset('images/products/'.$product->image)); ?>" alt="<?php echo e($product->name); ?>"  class="w-full h-full object-center object-cover lg:w-full lg:h-full">
        <?php else: ?>
            <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>"  class="w-full h-full object-center object-cover lg:w-full lg:h-full">
        <?php endif; ?>

    </div>
    <div class="mt-4 flex justify-between">
        <div>
            <h3 class="text-sm text-gray-700">
            <a href="<?php echo e(route('showProduct', ['id'=>$product->id])); ?>" class="text-xl sm:text-base ">
                <span aria-hidden="true" class="absolute inset-0"></span>
                <?php echo e($product->name); ?>

            </a>
            </h3>
            <p class="mt-1 text-gray-500">Min order: <?php echo e($product->range_1_min); ?></p>
        </div>
        <p class="text-xl sm:text-sm font-medium text-gray-900">Php <?php echo e($product->unit_price_1); ?></p>
    </div>
</div><?php /**PATH C:\xampp\htdocs\plantinda_\resources\views/components/product.blade.php ENDPATH**/ ?>