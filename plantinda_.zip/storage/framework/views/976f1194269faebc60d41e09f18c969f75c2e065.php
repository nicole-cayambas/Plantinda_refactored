
<?php $__env->startSection('dash_content'); ?>
<?php if(auth()->guard()->check()): ?>
<div class="m-0 sm:m-10">
    <h1>Good Day <?php if(auth()->guard()->check()): ?> <?php echo e(Auth()->user()->first_name); ?> <?php endif; ?>!</h1>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plantinda_\resources\views/dashboard/index.blade.php ENDPATH**/ ?>