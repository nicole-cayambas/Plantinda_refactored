
<?php $__env->startSection('dash_content'); ?>
    <div class="w-full mt-2 sm:m-10 flex flex-col gap-y-4">
        <p class="w-full text-center text-emerald-600">
            <?php echo e(session('success')); ?>

        </p>
        <div class="flex justify-center px-4 sm:justify-start">
            <a href="<?php echo e(route('createProduct')); ?>" class="w-full sm:w-1/4 p-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white text-center bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 cursor-pointer">Add Product</a>
        </div>
        <?php if(count($products) > 0): ?>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white shadow-md p-8 rounded-lg">
                <div class="w-full flex flex-col sm:flex-row gap-4">
                    <?php if(!str_starts_with($product->image, 'http')): ?>
                        <div class="w-full sm:w-1/6">
                            <img src="<?php echo e(asset('images/products/'.$product->image)); ?>" alt="<?php echo e($product->name); ?>" class="w-full rounded-md">
                        </div>
                    <?php else: ?>
                    <div class="w-full sm:w-1/6">
                        <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" class="w-full rounded-md">
                    </div>
                    <?php endif; ?>
                    <h3 class="w-full sm:w-1/6 text-center"><a href="/products/<?php echo e($product->id); ?>" class="text-lg font-bold"><?php echo e($product->name); ?></a></h3>
                    <p class="w-full sm:w-1/6 text-sm"><?php echo e(Str::limit($product->description, 120)); ?></p>
                        <div class="w-full sm:w-1/6 text-center">
                            <p class="font-bold">Unit Price</p>
                            <p class="">Php <?php echo e($product->unit_price_1); ?></p>
                            <p class="">Php <?php echo e($product->unit_price_2); ?></p>
                            <p class="">Php <?php echo e($product->unit_price_3); ?></p>
                            <p class="">Php <?php echo e($product->unit_price_4); ?></p>
                        </div>
                        <div class="w-full sm:w-1/6 text-center">
                            <p class="font-bold">Min - Max</p>
                            <p class=""><?php echo e($product->range_1_min); ?> - <?php echo e($product->range_1_max); ?></p>
                            <p class=""><?php echo e($product->range_2_min); ?> - <?php echo e($product->range_2_max); ?></p>
                            <p class=""><?php echo e($product->range_3_min); ?> - <?php echo e($product->range_3_max); ?></p>
                            <p class=""><?php echo e($product->range_4_min); ?> - <?php echo e($product->range_4_max); ?></p>
                        </div>
                    <div class="w-full sm:w-1/6 flex flex-col text-center gap-y-4">
                        <a href="<?php echo e(route('editProduct', ['id'=>$product->id])); ?>" class="w-full p-2 border-2 rounded-md">Edit</a>
                        <form action="<?php echo e(route('deleteProduct', $product)); ?>" method="get">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="w-full p-2 rounded-md text-white bg-red-500">Delete</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="mt-10 flex w-ful justify-center">
            <?php echo e($products->links()); ?>

        </div>
        <?php else: ?>
            <p>No products found</p>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plantinda_\resources\views/dashboard/products/index.blade.php ENDPATH**/ ?>